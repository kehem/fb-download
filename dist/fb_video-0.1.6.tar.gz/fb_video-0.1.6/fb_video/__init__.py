# fb_video/__init__.py
from .scraper import FacebookVideoScraper, FacebookResponse

__version__ = "0.1.6"  # Package version